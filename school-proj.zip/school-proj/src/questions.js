export class Question {
    static create(question) {
        return fetch('https://school-courses-429eb-default-rtdb.firebaseio.com/questions.json', {
            method: 'POST',
            body: JSON.stringify(question),
            header: {
                'Content-type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(response => console.log(response))
    }
}
