export function isValid (value) {
    return value.length >= 1;
}