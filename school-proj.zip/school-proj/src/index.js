//MODULES

import { Post } from './Post'
import { Question } from './questions'
import { isValid } from "./utils"
import './styles/styles.css'
import './styles/less.less'
import './styles/scss.scss'




const post = new Post('Webpack Post Title')

console.log('Post to String:', post.toString())

const form = document.getElementById('form');
const input = document.querySelector('#question-input')
const submitBtn = document.querySelector('#submit');
const namer = document.querySelector('#name-input')
const lastName = document.querySelector('#lastname-input')
const email = document.querySelector('#email-input');

//=========================================================================YOUTUBE
const video = document.querySelector('.toggler-play');
const multimedia = document.querySelector('.multimed');
const minPlayer = document.querySelector('.mini-player')
const closeVideo = document.querySelector('.cross-video');

document.addEventListener('click', (e) => {
  if (e.target.classList.contains('toggler-play')) {

    multimedia.classList.add('multimed--active');

  } else if (e.target.classList.contains('cross-video')) {
    multimedia.classList.remove('multimed--active');

  } else if (!minPlayer.contains(e.target)) {
    multimedia.classList.remove('multimed--active');
  }

})

form.addEventListener('submit', submitFormHandler)
input.addEventListener('input', () => {
    submitBtn.disabled = !isValid(input.value)
})


function submitFormHandler(e) {
    function radioCheck() {
        let socialBtn = document.querySelectorAll('.radio-btn');
        for (let i = 0; i < socialBtn.length; i++) {
            if (socialBtn[i].checked) {
                socialBtn[i].checked = false;
                return socialBtn[i].value;
            }

        }

    }
    e.preventDefault();
    if (isValid(input.value)) {
        const question = {
            'phone-number': input.value.trim(),
            name: namer.value.trim(),
            lastName: lastName.value.trim(),
            'email-address': email.value.trim(),
            date: new Date().toJSON(),
            refer: radioCheck()


        }
        submitBtn.disabled = true
        Question.create(question).then(() => {
            input.value = '';
            email.value = '';
            lastName.value = '',
                email.value = '';
            // input.className = '';
            namer.value = '';
            // namer.className = '';
            submitBtn.disabled = false;
        })
    }
}


